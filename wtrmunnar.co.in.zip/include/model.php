<div class="modal fade" id="quickEnq">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true"><img src="images/close.png" alt=""></span> </button>
        <div class="modal-body">
          <div class="modal-l"> <img src="images/wtr-logo.png" alt="" class="img-fluid">
            <h2>The Wild Ttrails</h2>
			
            <p>Resort, Munnar</p>
			<img class="icon2" src="images/icon.png">
          </div>
          <div class="modal-r">
            <h2>Quick Enquiry</h2>
            <div class="form-group">
              <input type="text" class="form-control" id="name" aria-describedby="" placeholder="Name">
            </div>
            <div class="form-group">
              <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Email">
            </div>
            <div class="form-group">
              <input type="text" class="form-control" id="phone" aria-describedby="" placeholder="Phone">
            </div>
            <div class="form-group">
              <textarea class="form-control" id="exampleFormControlTextarea1" rows="2" placeholder="Comments"></textarea>
            </div>
            <button type="button" class="btn btn-primary">SUBMIT</button>
          </div>
        </div>
      </div>
    </div>
  </div>