    <style>
	.sections-nobg { background: #0000007a;}
    </style>
	
	<div class="container-fluid sections-nobg">
      <div id="footer" class="container links-sec">
        <div class="row">
          <div class="col-md-12">
            <p class="text-uppercase"><a href="index.php">Home</a>|<a href="rooms.php">Cottage</a>|<a href="gallery.php">Gallery</a>|<a href="package.php">Packages</a>|<a href="contact.php">Contact</a>|<a href="https://g.page/the-wild-trails-resort-Munnar?share">Locate Us</a>|<a href="about.php">About</a></p>
          </div>
          <div class="col-md-12">
            <div class="social"><a href="https://www.facebook.com/thewildtrailsmunnar/"><img src="images/icon-fb.png" alt=""></a><a href="#"><img src="images/icon-insta.png" alt=""></a><a href="#"><img src="images/icon-whats.png" alt=""></a><a href="#"><img src="images/icon-.png" alt=""></a></div>
          </div>
          <div class="col-md-12"> 
            <p>Copyright © 2021 Wild Trail  Designed & Maintained by <a href="https://asiatech.in">Asiatech Inc</a>All rights reserved.</p>
          </div> 
        </div>
      </div>
    </div>